<?php

namespace Qcloud\Cos\Exception;

use Qcloud\Cos\Exception\ServiceResponseException;

class CosException extends ServiceResponseException {}
